import sys
import MySQLdb
import numpy as np
import json
from netCDF4 import Dataset
from collections import OrderedDict

def read_temp_db(Latitude, Longitude):
    db = MySQLdb.connect(host="localhost",  # your host
                         user="root",  # username
                         passwd="hala1983",  # password
                         db="testdb")  # name of the database

    # Create a Cursor object to execute queries.
    cur = db.cursor()

    cur.execute("SELECT * FROM CO_FILES WHERE FILE_NAME='/root/one.nc'")
    for row in cur.fetchall():
        # save nc file in dataset from the database
        # row[0]means retrieve first column in database of netcdf data
        cocol = Dataset(row[0])
	outputFilePath = "/root/CO_output.json"
    with cocol as ncFile:
        print("Unit of measurement")
        #print(ncFile["PRODUCT"].variables['carbonmonoxide_total_column'][0][0][0].units)
        latitude_list = []
        longitude_list = []
        co_scanline_position = 0
        co_ground_pixel_position = 0
        co_value = 0
        for lat_scanline_count in range(0, 288):
            for lat_ground_pixel_count in range(0, 214):
                lat_approximated_value = float('{:.4f}'.format(np.float32('{:.4f}'.format(
                    ncFile["PRODUCT"].variables['latitude'][0][lat_scanline_count][lat_ground_pixel_count])).item(0)))
                if Latitude == lat_approximated_value:
                    print("found latitude")
                    lat_dict = {"lat_scanline": lat_scanline_count, "lat_ground_pixel": lat_ground_pixel_count}
                    latitude_list.append(lat_dict)
                    print("in latitude")
                    print(lat_scanline_count)
                    print(lat_ground_pixel_count)
        for lon_scanline_count in range(0, 288):
            for lon_ground_pixel_count in range(0, 214):
                lon_approximated_value = float('{:.4f}'.format(np.float32('{:.4f}'.format(
                    ncFile["PRODUCT"].variables['longitude'][0][lon_scanline_count][lon_ground_pixel_count])).item(0)))
                if Longitude == lon_approximated_value:
                    print("found longitude")
                    long_dict = {"lon_scanline": lon_scanline_count, "lon_ground_pixel": lon_ground_pixel_count}
                    longitude_list.append(long_dict)
                    print("in longitude")
                    print(lon_scanline_count)
                    print(lon_ground_pixel_count)
        for long in longitude_list:
            for lat in latitude_list:
                print("scanline_common?")
                print(long.get("lon_scanline"))
                print(lat.get("lat_scanline"))
                print("ground_pixel_common?")
                print(long.get("lon_ground_pixel"))
                print(lat.get("lat_ground_pixel"))
                if (long.get("lon_scanline") == lat.get("lat_scanline")) & (
                        long.get("lon_ground_pixel") == lat.get("lat_ground_pixel")):
                    print("YES common")
                    print("scanline")
                    print(long.get("lon_scanline"))
                    print("ground_pixel")
                    print(lat.get("lat_ground_pixel"))
                    co_ground_pixel_position = long.get("lon_ground_pixel")
                    co_scanline_position = lat.get("lat_scanline")

        co_value = ncFile["PRODUCT"].variables['carbonmonoxide_total_column'][0][co_scanline_position][
            co_ground_pixel_position]
        print(co_value)
        #json_co_value = float(co_value)
        #data = {}
        #data['CO'] = []
        #data['CO'].append({
            #'value': json_co_value
        #})
        #with open('data.json', 'w') as outfile:
            #json.dump(data, outfile, indent=4)

        pollutant = "CO"
        pollutantValueArray = []
        pollutantValueArray.append({"time": {"instant": "2017-09-18T18:00:00Z"}, "uom": "mol m-2","value": str(co_value), "Longitude": Longitude, "Latitude": Latitude})
        #why order here should be reversed although it is not like this on csvToDB ?
        #pollutantValues = {pollutant: pollutantValueArray}
        #pollutantValueArray.append(OrderedDict("time",("instant","2017-09-18T18:00:00Z")), ("uom",str(data["uom"])),("value",str(data["value"])),("Longitude","N/A"), ("Latitude","N/A"))
        pollutantValues = {pollutant: pollutantValueArray}
        outfile = open(outputFilePath, 'w')
        outfile.write(json.dumps(OrderedDict(pollutantValues), indent=4, sort_keys=True))

   
    db.commit()
    db.close()

    return str(outputFilePath)

if __name__ == '__main__':
    t = read_temp_db((sys.argv[1]), (sys.argv[2]))
    print(t)

