import csv

with open('/root/PythonWork_CO/SigfoxSensorData.csv') as csvfile:
    readCSV = csv.reader(csvfile, delimiter=';')
    latitude = []
    longitude = []
    temp = []
    dates = []
    for row in readCSV:
        latitudeEntry = row[0]
        longitudeEntry = row[2]
        tempEntry = row[6]
        datesEntry = row[18]

        latitude.append(latitudeEntry)
        longitude.append(longitudeEntry)
        temp.append(tempEntry)
        dates.append(datesEntry)

    print(latitude)
    print(longitude)
    print(temp)
    print(dates)
    # now, which temperature value do u want?

    whichDate = input('Enter date?:')
    coldex = dates.index(whichDate)
    temp = temp[coldex]
    print('The Temperature of',whichDate,'is:',temp)