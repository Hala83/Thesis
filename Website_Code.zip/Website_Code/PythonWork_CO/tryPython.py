import MySQLdb
import numpy
db = MySQLdb.connect(host="localhost",  # your host 
                     user="root",       # username
                     passwd="hala1983",     # password
                     db="testdb")   # name of the database
 
# Create a Cursor object to execute queries.
cur = db.cursor()
from netCDF4 import Dataset
cur.execute("SELECT * FROM TrailTable3 WHERE f='/root/LST_in.nc'")   
for row in cur.fetchall() :
#save nc file in dataset from the database
   dataset2 = Dataset(row[2])
with dataset2 as ncFile2:
	nc_attrs2 = ncFile2.variables['LST'][500][500]
	print (nc_attrs2)

db.commit()
db.close()